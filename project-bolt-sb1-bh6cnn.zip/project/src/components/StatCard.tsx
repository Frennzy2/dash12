import React from 'react';
import { InformationCircleIcon } from '@heroicons/react/24/outline';
import clsx from 'clsx';

interface StatCardProps {
  title: string;
  value: string | number;
  chart?: React.ReactNode;
  gaugeValue?: number;
  gaugeColor?: 'green' | 'blue';
}

export default function StatCard({ title, value, chart, gaugeValue, gaugeColor }: StatCardProps) {
  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2 text-gray-500 text-sm">
          {title}
          <InformationCircleIcon className="h-4 w-4 text-gray-400" />
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div className="text-2xl font-semibold">{value}</div>
        {gaugeValue && (
          <div className="relative w-16 h-16">
            <svg className="w-full h-full" viewBox="0 0 36 36">
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#eee"
                strokeWidth="3"
                strokeDasharray="100, 100"
              />
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke={gaugeColor === 'green' ? '#10b981' : '#6e56cf'}
                strokeWidth="3"
                strokeDasharray={`${gaugeValue}, 100`}
              />
            </svg>
          </div>
        )}
        {chart}
      </div>
    </div>
  );
}