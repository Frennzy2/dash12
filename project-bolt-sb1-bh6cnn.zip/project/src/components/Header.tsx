import React from 'react';
import { BellIcon, ChevronDownIcon } from '@heroicons/react/24/outline';
import { format } from 'date-fns';

export default function Header() {
  const lastImportTime = new Date('2022-12-23T10:05:00');

  return (
    <div className="flex items-center justify-between mb-8">
      <div className="flex items-center gap-4">
        <button className="flex items-center gap-2 text-gray-600 hover:text-gray-800">
          <span>← Dashboard</span>
        </button>
      </div>
      <div className="flex items-center gap-6">
        <div className="flex items-center text-sm text-gray-500">
          <span>Last import was made: {format(lastImportTime, 'MMM dd, yyyy hh:mm a')}</span>
        </div>
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 text-gray-600 border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50">
            <span>Date range</span>
            <ChevronDownIcon className="h-4 w-4" />
          </button>
          <button className="flex items-center gap-2 text-gray-600 border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50">
            <span>Umar2022 UAT</span>
            <ChevronDownIcon className="h-4 w-4" />
          </button>
          <button className="text-gray-600 hover:text-gray-800">
            <BellIcon className="h-6 w-6" />
          </button>
        </div>
      </div>
    </div>
  );
}