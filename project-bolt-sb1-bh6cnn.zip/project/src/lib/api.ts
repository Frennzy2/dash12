import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api'
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const login = (email: string, password: string) =>
  api.post('/auth/login', { email, password });

export const register = (email: string, password: string, name: string) =>
  api.post('/auth/register', { email, password, name });

export const getTrades = () =>
  api.get('/trades');

export const addTrade = (trade: {
  symbol: string;
  entry_price: number;
  exit_price: number;
  quantity: number;
  date: string;
  type: string;
}) => api.post('/trades', trade);

export const getStats = () =>
  api.get('/trades/stats');