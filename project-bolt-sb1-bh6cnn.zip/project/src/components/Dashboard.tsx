import React from 'react';
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';
import StatCard from './StatCard';
import Header from './Header';

const data = [
  { date: '01/02/22', value: 0 },
  { date: '05/04/22', value: 400000 },
  { date: '07/20/22', value: 800000 },
  { date: '10/04/22', value: 1200000 },
  { date: '12/23/22', value: 1400000 }
];

const dailyData = [
  { date: '12/19', value: 50000 },
  { date: '12/20', value: -20000 },
  { date: '12/21', value: 75000 },
  { date: '12/22', value: 45000 },
  { date: '12/23', value: 90000 }
];

export default function Dashboard() {
  return (
    <div className="flex-1 p-8 bg-background">
      <Header />
      
      <div className="grid grid-cols-5 gap-4 mb-8">
        <StatCard
          title="Net P&L"
          value="$1,374,183.95"
        />
        <StatCard
          title="Trade Win %"
          value="66.67%"
          gaugeValue={67}
          gaugeColor="blue"
        />
        <StatCard
          title="Profit Factor"
          value="5.68"
        />
        <StatCard
          title="Day Win %"
          value="79.55%"
          gaugeValue={80}
          gaugeColor="green"
        />
        <StatCard
          title="Trade Expectancy"
          value="$7,154.34"
        />
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-gray-600">Zella Score</h3>
            <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">BETA</span>
          </div>
          <div className="flex justify-center">
            <div className="text-4xl font-bold text-primary">97.3</div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-gray-600 mb-6">Daily Net Cumulative P&L</h3>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={data} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
              <XAxis dataKey="date" hide />
              <YAxis hide />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="value"
                stroke="#6e56cf"
                fill="#6e56cf"
                fillOpacity={0.2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-gray-600 mb-6">Net Daily P&L</h3>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={dailyData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
              <XAxis dataKey="date" hide />
              <YAxis hide />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="value"
                stroke="#10b981"
                fill="#10b981"
                fillOpacity={0.2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}