import React from 'react';
import { 
  ChartBarIcon, 
  BookOpenIcon, 
  DocumentTextIcon,
  PresentationChartLineIcon,
  AcademicCapIcon,
  ClipboardDocumentIcon,
  PlayCircleIcon,
  ArrowPathIcon,
  UserGroupIcon
} from '@heroicons/react/24/outline';

const menuItems = [
  { icon: ChartBarIcon, text: 'Dashboard', active: true },
  { icon: DocumentTextIcon, text: 'Daily Journal' },
  { icon: ClipboardDocumentIcon, text: 'Trade Log' },
  { icon: PresentationChartLineIcon, text: 'Reports' },
  { icon: ChartBarIcon, text: 'Insights' },
  { icon: AcademicCapIcon, text: 'University' },
  { icon: BookOpenIcon, text: 'Notebook' },
  { icon: DocumentTextIcon, text: 'Playbook' },
  { icon: UserGroupIcon, text: 'Challenges', new: true },
  { icon: PlayCircleIcon, text: 'Trade Replay' },
  { icon: ArrowPathIcon, text: 'Backtesting', new: true },
  { icon: UserGroupIcon, text: 'Mentor Mode' }
];

export default function Sidebar() {
  return (
    <div className="w-64 bg-[#1a1625] min-h-screen p-4 flex flex-col">
      <div className="mb-8">
        <img src="/logo.png" alt="TradingZella" className="h-8" />
      </div>
      
      <button className="w-full bg-[#6e56cf] text-white py-2 px-4 rounded-lg mb-6 flex items-center justify-center gap-2 hover:bg-[#5d48b6]">
        <PlusIcon className="h-5 w-5" />
        Add Trade
      </button>

      <nav className="flex-1">
        {menuItems.map((item, index) => (
          <div 
            key={index}
            className={`flex items-center gap-3 px-4 py-2 rounded-lg mb-1 cursor-pointer ${
              item.active ? 'bg-[#2a2435] text-white' : 'text-gray-400 hover:bg-[#2a2435] hover:text-white'
            }`}
          >
            <item.icon className="h-5 w-5" />
            <span>{item.text}</span>
            {item.new && (
              <span className="ml-auto text-xs bg-[#6e56cf] px-2 py-0.5 rounded-full">
                NEW
              </span>
            )}
          </div>
        ))}
      </nav>
    </div>
  );
}

function PlusIcon(props: React.ComponentProps<'svg'>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}