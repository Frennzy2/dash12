import express from 'express';
import { pool } from '../index.js';

const router = express.Router();

// Get all trades
router.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM trades WHERE user_id = $1 ORDER BY date DESC',
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch trades' });
  }
});

// Add new trade
router.post('/', async (req, res) => {
  const { symbol, entry_price, exit_price, quantity, date, type } = req.body;
  
  try {
    const { rows } = await pool.query(
      `INSERT INTO trades (user_id, symbol, entry_price, exit_price, quantity, date, type)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [req.user.id, symbol, entry_price, exit_price, quantity, date, type]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create trade' });
  }
});

// Get trade statistics
router.get('/stats', async (req, res) => {
  try {
    const stats = await pool.query(
      `SELECT 
        COUNT(*) FILTER (WHERE (exit_price - entry_price) * quantity > 0)::float / COUNT(*)::float * 100 as win_rate,
        SUM((exit_price - entry_price) * quantity) as net_pnl,
        COUNT(DISTINCT DATE(date)) as trading_days
       FROM trades 
       WHERE user_id = $1`,
      [req.user.id]
    );
    res.json(stats.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

export const tradesRouter = router;