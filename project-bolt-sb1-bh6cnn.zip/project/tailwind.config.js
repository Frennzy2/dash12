/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#6e56cf',
        secondary: '#2a2435',
        background: '#f8f9fb',
        sidebar: '#1a1625'
      }
    },
  },
  plugins: [],
}